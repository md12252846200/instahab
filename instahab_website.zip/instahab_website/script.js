const form = document.getElementById("download-form");
const input = document.getElementById("media-url");
const statusBox = document.getElementById("status");
const previewCard = document.getElementById("preview-card");
const previewTitle = document.getElementById("preview-title");
const fileType = document.getElementById("file-type");
const mediaPreview = document.getElementById("media-preview");
const fileUrl = document.getElementById("file-url");
const downloadLink = document.getElementById("download-link");
const checkButton = document.getElementById("check-button");

const extensions = {
  image: /\.(png|jpe?g|gif|webp|avif|bmp)(?:$|[?#])/i,
  video: /\.(mp4|webm|mov|m4v|ogv)(?:$|[?#])/i
};

function showStatus(message, kind = "info") {
  statusBox.textContent = message;
  statusBox.className = `status ${kind}`;
  statusBox.hidden = false;
}
function clearPreview() {
  previewCard.hidden = true;
  mediaPreview.replaceChildren();
  statusBox.hidden = true;
}
function isSafeHttpUrl(value) {
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:";
  } catch {
    return false;
  }
}
function makePreview(url, kind) {
  if (kind === "image") {
    const img = document.createElement("img");
    img.src = url;
    img.alt = "Media preview";
    img.referrerPolicy = "no-referrer";
    img.addEventListener("error", () => {
      img.remove();
      showStatus("The host did not allow an image preview. You can still try opening the original file link.", "info");
    }, { once: true });
    mediaPreview.append(img);
  } else if (kind === "video") {
    const video = document.createElement("video");
    video.src = url;
    video.controls = true;
    video.preload = "metadata";
    video.referrerPolicy = "no-referrer";
    video.addEventListener("error", () => {
      video.remove();
      showStatus("The host did not allow a video preview. You can still try opening the original file link.", "info");
    }, { once: true });
    mediaPreview.append(video);
  } else {
    const label = document.createElement("p");
    label.className = "small-note";
    label.textContent = "This URL does not look like a direct image or video file. It may be a webpage rather than a media file.";
    mediaPreview.append(label);
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  clearPreview();
  const url = input.value.trim();

  if (!isSafeHttpUrl(url)) {
    showStatus("Please enter a valid HTTP or HTTPS URL.", "error");
    return;
  }

  let parsed;
  try { parsed = new URL(url); } catch {
    showStatus("That link could not be read. Please check it and try again.", "error");
    return;
  }

  // Avoid local/private-network destinations in this simple front-end checker.
  const host = parsed.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".localhost") || host === "127.0.0.1" ||
      host === "0.0.0.0" || host.startsWith("10.") || host.startsWith("192.168.") ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(host) || host === "[::1]") {
    showStatus("For safety, local or private-network URLs are not supported.", "error");
    return;
  }

  // This starter deliberately does not extract media from social-post pages.
  if (/(^|\.)instagram\.com$/i.test(host) || /(^|\.)instagr\.am$/i.test(host)) {
    showStatus("Instagram post, Reel, and Story page links are not extracted by this starter site. Use Instagram's official download/export tools or an authorized API for content you own or have permission to save.", "info");
    return;
  }

  let kind = "unknown";
  if (extensions.image.test(parsed.pathname + parsed.search)) kind = "image";
  else if (extensions.video.test(parsed.pathname + parsed.search)) kind = "video";

  previewTitle.textContent = parsed.hostname;
  fileType.textContent = kind === "image" ? "IMAGE" : kind === "video" ? "VIDEO" : "LINK";
  fileUrl.textContent = url;
  downloadLink.href = url;
  downloadLink.setAttribute("download", "");
  downloadLink.rel = "noopener noreferrer";
  downloadLink.target = "_blank";
  makePreview(url, kind);
  previewCard.hidden = false;

  if (kind === "unknown") {
    showStatus("Link checked. This does not appear to be a direct image/video file, so downloading may not work. Use a direct file URL you own or are authorized to save.", "info");
  } else {
    showStatus("Link format looks suitable. Preview and download depend on the file host's permissions and settings.", "info");
  }
});
